﻿using BitmonGeneration1.Source.Battles;

namespace BitmonGeneration1.Source.Moves.Reflexive
{
    public abstract class ReflexiveStatusMove : Move
    {
        public override sealed void ExecuteAndUpdate(
            BattleBitmon user, BattleBitmon defender)
        {
            Execute(user);
        }

        protected abstract void Execute(BattleBitmon user);
        
        protected void SetLastMoveAndSubtractPP(BattleBitmon user)
        {
            user.LastMoveUsed = this;
            SubtractPP(1);
        }
        
        protected ReflexiveStatusMove(int index, string name, Type type, int startingPP, int absoluteMaxPP)
            : base(index, name, type, startingPP, absoluteMaxPP, 0, Category.STATUS) { }
    }
}
