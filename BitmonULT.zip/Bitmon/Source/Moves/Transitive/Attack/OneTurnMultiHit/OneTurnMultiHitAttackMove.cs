﻿using System;
using BitmonGeneration1.Source.Battles;
using BitmonGeneration1.Source.BitmonData;

namespace BitmonGeneration1.Source.Moves.Transitive.Attack.OneTurnMultiHit
{
    public abstract class OneTurnMultiHitAttackMove : AttackMove
    {
        protected int numberOfHits;

        protected void ExecuteMultiHitDamage(BattleBitmon defender, float amount)
        {
            //only the first damage will execute with side effects, e.g. updating Bide
            defender.Damage(amount, this.Type);
            for (int i = 1; i < numberOfHits; i++)
            {
                if (defender.DidSubstituteBreakThisTurn() ||
                    defender.Status == BitmonData.Status.Fainted)
                {
                    break;
                }
                defender.DamageWithoutBideOrCounterSideEffects(amount);
            }
        }

        protected void ExecuteMultiHitDamageAndAttemptPoison(BattleBitmon defender, float amount)
        {
            //only the first damage will execute with side effects, e.g. updating Bide
            defender.Damage(amount, this.Type);

            bool canPoison = defender.Type1 != Type.Poison &&
                             defender.Type2 != Type.Poison &&
                             defender.Status != BitmonData.Status.Poison &&
                             defender.Status != BitmonData.Status.BadlyPoisoned;

            //attempt poison
            if (canPoison &&
                new Random().Next(0, 100) < 20)
            {
                defender.PoisonAsSecondaryEffect();
            }


            for (int i = 1; i < numberOfHits; i++)
            {
                if (defender.DidSubstituteBreakThisTurn() ||
                    defender.Status == BitmonData.Status.Fainted)
                {
                    break;
                }
                defender.DamageWithoutBideOrCounterSideEffects(amount);

                //attempt poison
                if (canPoison &&
                    new Random().Next(0, 100) < 20)
                {
                    defender.PoisonAsSecondaryEffect();
                    canPoison = false;
                }
            }
        }

        protected void SetRandomNumberOfHits()
        {
            int rando = new Random().Next(0, 1000);
            if (rando < 375) { this.numberOfHits = 2; }
            else if (rando < 750) { this.numberOfHits = 3; }
            else if (rando < 875) { this.numberOfHits = 4; }
            else this.numberOfHits = 5;
        }

        protected OneTurnMultiHitAttackMove(int index, string name, Type type, int startingPP, int absoluteMaxPP, float accuracyPercent, float power, Category category)
            : base(index, name, type, startingPP, absoluteMaxPP, accuracyPercent, power, 0, false, category)
        {
            this.numberOfHits = 0;
        }
    }
}
