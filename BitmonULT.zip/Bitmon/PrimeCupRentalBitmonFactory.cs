﻿using BitmonGeneration1.Source.Moves;
using BitmonGeneration1.Source.Moves.Reflexive;
using BitmonGeneration1.Source.Moves.Transitive.Attack.MultiTurn;
using BitmonGeneration1.Source.Moves.Transitive.Attack.OneTurnMultiHit;
using BitmonGeneration1.Source.Moves.Transitive.Attack.OneTurnOneHit;
using BitmonGeneration1.Source.BitmonData;
using System;

namespace BitmonStadiumConsoleApp
{
    public static class RentalPokemonFactory
    {
        private static Bitmon Create(int number, float level, Move move1, Move move2, Move move3, Move move4)
        {
            return Bitmon.Builder.Init(number, level)
                .Move1(move1)
                .Move2(move2)
                .Move3(move3)
                .Move4(move4)
              
                .Create();
        }

        public static Bitmon PrimeCup(int number)
        {
            switch (number)
            {
                case 1: // Charmon
                    return Create(1, 100,new ThunderShock(), new Spark(), new Ember(), new FlameThrower());

                case 2: // Bitmeleon
                    return Create(2, 100,new Ember(), new FireFang(), new FireSping(), new FlameThrower());

                case 3: // Pikamon
                    return Create(3,100, new ChargeBeam(), new VoltSwitch(), new FireFang(), new FireSping());

                case 4: // Qwertymon
                    return Create(4, 100,new ThunderShock(), new Spark(), new ChargeBeam(), new VoltSwitch());

                case 5: // Squimon
                    return Create(5,100, new FrostBreath(), new PowderSnow(), new Bubble(), new WaterFall());

                case 6: // Worbimon
                    return Create(6, 100,new WaterGun(), new PoisonGun(), new Bubble(), new WaterFall());

                case 7: // Icemon
                    return Create(7,100, new PoisonGun(), new IceShard(), new Hypothermia(), new WaterGun());

                case 8: // Dragonice
                    return Create(8,100, new IceShard(), new FrostBreath(), new PowderSnow(), new Hypothermia());

                case 9: // Tirimon
                    return Create(9,100, new FlameThrower(), new Hypothermia(), new PoisonGun(), new Spark());

                case 10: // Naidormon
                    return Create(10,100, new FireSpin(), new IceShard(), new WaterFall(), new VoltSwitch());



                default: throw new ArgumentException("The given index " + number + " is an invalid pokemon number");
            }
        }
    }
}
