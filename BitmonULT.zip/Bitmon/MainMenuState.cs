﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BitmonStadiumConsoleApp
{
    public enum MainMenuState
    {
        MAIN,
        MOVE,
        ITEM,
        BITMONFORITEM,
        BITMONFORSWITCH,
    }
}
